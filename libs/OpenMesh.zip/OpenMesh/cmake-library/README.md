
## Resources

 - https://pabloariasal.github.io/2018/02/19/its-time-to-do-cmake-right/
 - https://crascit.com/professional-cmake/