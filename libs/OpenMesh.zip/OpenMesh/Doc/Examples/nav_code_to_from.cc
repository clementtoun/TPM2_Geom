// Get the handle of the to vertex
OpenMesh::Concepts::KernelT::to_vertex_handle();

// Get the handle of the from vertex
OpenMesh::Concepts::KernelT::from_vertex_handle();
