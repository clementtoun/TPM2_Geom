/*
 * main.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: ebke
 */

#include <benchmark/benchmark_api.h>

BENCHMARK_MAIN();
